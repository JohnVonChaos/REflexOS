docs/self-architecture.md @ v1

> - 2024‑05‑12  Update: moved SRG & background cognition description to *srgService.getSrgView* for better clarity.